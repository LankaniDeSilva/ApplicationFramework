package bookservice;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/books")
public class BookService {
	List<Book> books;

	public BookService() {
		books = Books.getBooks();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Book> getBooks() {
		return books;
	}

	@Path("{id}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Book getBook(@PathParam("id") int id) {
		for (Book b : books) {
			if (b.getId() == id)
				return b;
		}
		// book with the given id is not found, so throw 404 error
		throw new NotFoundException();
	}

	@Path("/add_book/{book_id}/{book_name}/{book_price}")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public void addBook(@PathParam("book_id") int book_id, @PathParam("book_name") String book_name, @PathParam("book_price") double book_price) {
		Books.addBook(book_id, book_name, book_price);
		books = Books.getBooks();
	}

	@Path("/delete_book/{book_id}")
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	public void deleteBook(@PathParam("book_id") int book_id) {
		for (Book book : books) {
			if (book.getId() == book_id) {
				Books.deleteBook(book);
				books = Books.getBooks();
				return;
			}
		}
		// book with the given id is not found, so throw 404 error
		throw new NotFoundException();
	}
}