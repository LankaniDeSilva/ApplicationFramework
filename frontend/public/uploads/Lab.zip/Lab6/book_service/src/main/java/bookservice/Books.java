package bookservice;

import java.util.ArrayList;
import java.util.List;

public class Books {
	private static ArrayList<Book> books = new ArrayList<>();
	static {
		books.add(new Book(1, "The Outliers", 500));
		books.add(new Book(2, "World Is Flat", 550));
	}

	public static List<Book> getBooks() {
		return books;
	}

	public static void addBook(int book_id, String book_name, double book_price) {
		books.add(new Book(book_id, book_name, book_price));
	}

	public static void deleteBook(Book book) {
		books.remove(book);
	}
}